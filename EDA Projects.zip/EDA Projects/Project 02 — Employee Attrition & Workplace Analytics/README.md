\## Employee Attrition \& Workplace Analytics



\## Project Objective

The objective of this project is to analyze employee attrition and identify workplace and employee-related factors associated with employees leaving an organization.



\## Dataset

Dataset: IBM HR Analytics Employee Attrition \& Performance Dataset

* Records: 1,470 employees
* Columns: 35
* Tools: Python, Pandas, NumPy, Matplotlib, Seaborn

The dataset contains information about employee demographics, job roles, income, satisfaction, overtime, work-life balance, business travel, and attrition status.

\## Analysis Performed

The project includes:

* Data understanding and descriptive statistics
* Missing value and duplicate analysis
* Overall attrition analysis
* Department and job role analysis
* Overtime and business travel analysis
* Monthly income analysis
* Job satisfaction analysis
* Distance from home analysis
* Age and work-life balance analysis
* Employee tenure analysis
* Gender and marital status analysis
* Correlation and outlier analysis
* Data visualizations using charts, count plots, histograms, box plots, and heatmaps

\## Key Findings

* The overall employee attrition rate was 16.12%.
* Employees working overtime had a higher attrition rate (30.53%) compared with employees without overtime (10.44%).
* Sales had an attrition rate of 20.63%, while Research \& Development had 13.84%.
* Employees who left had lower average monthly income than employees who stayed.
* Employees who left had a higher average distance from home.
* Sales Representatives had the highest observed job-role attrition rate at 39.76%.
* Employees who left were younger on average than employees who stayed.
* Employees with lower job satisfaction and work-life balance showed higher observed attrition rates.
* Employees who stayed had longer average tenure at the company.

\## Important Insights

The analysis indicates that employee attrition is associated with multiple factors rather than a single variable. Overtime, income, job satisfaction, work-life balance, distance from home, business travel, job role, age, and tenure show noticeable differences between employees who stayed and those who left.

These findings can help organizations identify employee groups with higher observed attrition and support further workforce and retention analysis. The analysis shows associations within the dataset and does not establish that any particular factor directly causes attrition.

