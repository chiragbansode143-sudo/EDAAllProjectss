# E-Commerce Sales & Customer Behavior Analysis

## Project Objective

The objective of this project is to analyze e-commerce sales data using Python and identify important patterns in sales, products, customers, countries, orders, and cancellations.

The analysis aims to understand revenue performance, customer purchasing behavior, product demand, sales trends, and important business KPIs.

## Dataset

**Dataset:** UCI Online Retail Dataset

The dataset contains transactional retail information such as:

* Invoice number
* Product code and description
* Quantity
* Invoice date
* Unit price
* Customer ID
* Country

A Revenue column was created using:

`Revenue = Quantity × UnitPrice`

## Analysis Performed

The project performs:

* Data cleaning and duplicate removal
* Missing-value and data-quality analysis
* Revenue and order analysis
* Product-wise revenue and quantity analysis
* Country-wise revenue and order analysis
* Monthly and weekly sales trend analysis
* Average Order Value calculation
* Customer revenue analysis
* Cancellation and cancellation-rate analysis
* Revenue outlier detection using IQR
* Quantity, price, and revenue distribution analysis
* Price vs quantity and order quantity vs revenue analysis
* Correlation analysis
* Country-month revenue analysis

Various histograms, box plots, bar charts, line charts, scatter plots, and heatmaps are used for visualization.

## Key Findings

The analysis identifies:

* Top products by revenue and quantity sold
* Top countries by revenue and number of orders
* Highest-value customers
* Average Order Value
* Monthly and weekly sales patterns
* Cancellation rate and cancellation value
* Revenue outliers
* Relationships between price, quantity, and revenue

The exact numerical values are generated in the Jupyter Notebook.

## Important Insights

* Revenue and quantity provide different views of product performance.
* A small number of customers or products may contribute significantly to overall revenue.
* Sales activity varies across countries and time periods.
* Average Order Value helps understand typical order size.
* Cancellation patterns can highlight products or periods requiring further investigation.
* Outliers should be investigated rather than automatically removed because they may represent genuine high-value transactions.
* Data analysis and visualization help convert raw transaction data into useful business insights.
